<template lang="">

    <div>
        <h1 class="text-danger"> jhfakdfaksdfhkasdfkasdjhf</h1>
    </div>
</template>


<script setup>
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

</script>


<style lang="">

</style>